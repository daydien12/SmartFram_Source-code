
#include "smartfram_encryptionAES.h"
#include "smartfram_structpayload.h"
CRYP_HandleTypeDef hcryp;
DMA_HandleTypeDef hdma_aes_in;
DMA_HandleTypeDef hdma_aes_out;

__ALIGN_BEGIN static const uint32_t pPrivateKeyAES[4] __ALIGN_END = {0x2B7E1516, 0x28AED2A6, 0xABF71588, 0x09CF4F3C};
__ALIGN_BEGIN static const uint32_t pDeviceKeyAES[4] __ALIGN_END  = {0x603DEB10, 0x15CA71BE, 0x2B73AEF0, 0x857D7781};
#define ECB               1
#define CBC               2
#define CTR               3

#define PLAINTEXT_SIZE          ((uint32_t)16)
#define AES_TEXT_SIZE           ((uint32_t)16)


void Smartfram_EncryptedLayer1(uint8_t *InputData, uint8_t Length, uint8_t *OutputData)
{
	#define BUG 0
	uint8_t aEncryptedText[85]	= {0};
	uint8_t aInputText[85]			= {0};
	uint8_t *TempInputData = InputData;
	uint8_t TempLength;
	uint8_t CountLength;
	uint8_t CountAddZero;
	uint8_t CountCopyData;

	for(CountLength = 1; CountLength < 6; CountLength++)
	{
		TempLength = 16 * CountLength;
		if(TempLength >= Length)
			break;
		else
			TempLength = 0;
	}

	for(CountAddZero = 0; CountAddZero < TempLength; CountAddZero++)
	{
			aInputText[CountAddZero] = *TempInputData++;
	}

  if (HAL_CRYP_DeInit(&hcryp) != HAL_OK)
  {
    Error_Handler();
  }	

  hcryp.Instance = AES;
  hcryp.Init.DataType      = CRYP_DATATYPE_8B;
  hcryp.Init.KeySize       = CRYP_KEYSIZE_128B;
  hcryp.Init.Algorithm     = CRYP_AES_ECB;
  hcryp.Init.pKey          = (uint32_t *)pPrivateKeyAES;
  hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_BYTE;

  if (HAL_CRYP_Init(&hcryp) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  if (HAL_CRYP_Encrypt_DMA(&hcryp, (uint32_t*)aInputText, TempLength, (uint32_t*)aEncryptedText) != HAL_OK)
  {
    /* Processing Error */
    Error_Handler();
  }
  while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY){}

	#if BUG
		uint8_t BufferCounter;
		uint8_t *ArrSerial;
		uint8_t CountBlock = 0;	
	#endif		

	#if BUG
		ArrSerial = aInputText;
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA IN AES 128 ECB encryption LAYOUT1 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		APP_PPRINTF( "%d\n\r", TempLength);
		
		for (BufferCounter = 0; BufferCounter < 16; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif		

	#if BUG
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA OUT AES 128 ECB encryption LAYOUT1 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		ArrSerial = (uint8_t*)aEncryptedText;
		for (BufferCounter = 0; BufferCounter < 16; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif

	for(CountCopyData = 0; CountCopyData < TempLength; CountCopyData++)
	{
		OutputData[CountCopyData] =  aEncryptedText[CountCopyData];
	}
}

void Smartfram_DecryptedLayer1(uint8_t *InputData, uint8_t Length, uint8_t *OutputData)
{
	#define BUG 0
	uint8_t aDecryptedText[85]	= {0};
	uint8_t aInputText[85]			= {0};
	uint8_t TempLength;
	uint8_t CountLength;
	uint8_t CountCopyData;

	for(CountLength = 1; CountLength < 6; CountLength++)
	{
		TempLength = 16 * CountLength;
		if(TempLength >= Length)
			break;
		else
			TempLength = 0;
	}

  if (HAL_CRYP_DeInit(&hcryp) != HAL_OK)
  {
    Error_Handler();
  }	

  hcryp.Instance = AES;
  hcryp.Init.DataType      = CRYP_DATATYPE_8B;
  hcryp.Init.KeySize       = CRYP_KEYSIZE_128B;
  hcryp.Init.Algorithm     = CRYP_AES_ECB;
  hcryp.Init.pKey          = (uint32_t *)pPrivateKeyAES;
  hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_BYTE;

  if(HAL_CRYP_Init(&hcryp) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  if(HAL_CRYP_Decrypt_DMA(&hcryp, (uint32_t*)InputData, TempLength, (uint32_t*)aDecryptedText) != HAL_OK)
  {
    /* Processing Error */
    Error_Handler();
  }
  while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY){}

	#if BUG
		uint8_t BufferCounter;
		uint8_t *ArrSerial;
		uint8_t CountBlock = 0;	
	#endif		

	#if BUG
		ArrSerial = InputData;
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA IN AES 128 ECB decryption LAYOUT1 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		APP_PPRINTF( "%d\n\r", TempLength);
		
		for (BufferCounter = 0; BufferCounter < 16; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif		

	#if BUG
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA OUT AES 128 ECB decryption LAYOUT1 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		ArrSerial = (uint8_t*)aDecryptedText;
		for (BufferCounter = 0; BufferCounter < 16; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif

	for(CountCopyData = 0; CountCopyData < TempLength; CountCopyData++)
	{
		OutputData[CountCopyData] =  aDecryptedText[CountCopyData];
	}	
}

void Smartfram_EncryptedLayer2(uint8_t *InputData, uint8_t Length, uint8_t *OutputData)
{
	#define BUG 0
	uint8_t aEncryptedText[85]	= {0};
	uint8_t aInputText[85]			= {0};
	uint8_t *TempInputData = InputData;
	uint8_t TempLength;
	uint8_t CountLength;
	uint8_t CountAddZero;
	uint8_t CountCopyData;

	for(CountLength = 1; CountLength < 6; CountLength++)
	{
		TempLength = 16 * CountLength;
		if(TempLength >= Length)
			break;
		else
			TempLength = 0;
	}

	for(CountAddZero = 0; CountAddZero < TempLength; CountAddZero++)
	{
			aInputText[CountAddZero] = *TempInputData++;
	}

  if (HAL_CRYP_DeInit(&hcryp) != HAL_OK)
  {
    Error_Handler();
  }	

  hcryp.Instance = AES;
  hcryp.Init.DataType      = CRYP_DATATYPE_8B;
  hcryp.Init.KeySize       = CRYP_KEYSIZE_128B;
  hcryp.Init.Algorithm     = CRYP_AES_ECB;
  hcryp.Init.pKey          = (uint32_t *)pDeviceKeyAES;
  hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_BYTE;

  if (HAL_CRYP_Init(&hcryp) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  if (HAL_CRYP_Encrypt_DMA(&hcryp, (uint32_t*)aInputText, TempLength, (uint32_t*)aEncryptedText) != HAL_OK)
  {
    /* Processing Error */
    Error_Handler();
  }
  while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY){}

	#if BUG
		uint8_t BufferCounter;
		uint8_t *ArrSerial;
		uint8_t CountBlock = 0;	
	#endif		

	#if BUG
		ArrSerial = aInputText;
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA IN AES 128 ECB encryption LAYOUT2 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		APP_PPRINTF( "%d\n\r", TempLength);

		for (BufferCounter = 0; BufferCounter < TempLength; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif		

	#if BUG
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA OUT AES 128 ECB encryption LAYOUT2 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		ArrSerial = (uint8_t*)aEncryptedText;
		for (BufferCounter = 0; BufferCounter < TempLength; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif

	for(CountCopyData = 0; CountCopyData < TempLength; CountCopyData++)
	{
		OutputData[CountCopyData] =  aEncryptedText[CountCopyData];
	}
}

void Smartfram_DecryptedLayer2(uint8_t *InputData, uint8_t Length, uint8_t *OutputData)
{
	#define BUG 0	
	uint8_t aDecryptedText[85]	= {0};
	uint8_t aInputText[85]			= {0};
	uint8_t TempLength;
	uint8_t CountLength;
	uint8_t CountCopyData;

	for(CountLength = 1; CountLength < 6; CountLength++)
	{
		TempLength = 16 * CountLength;
		if(TempLength >= Length)
			break;
		else
			TempLength = 0;
	}

  if (HAL_CRYP_DeInit(&hcryp) != HAL_OK)
  {
    Error_Handler();
  }	

  hcryp.Instance = AES;
  hcryp.Init.DataType      = CRYP_DATATYPE_8B;
  hcryp.Init.KeySize       = CRYP_KEYSIZE_128B;
  hcryp.Init.Algorithm     = CRYP_AES_ECB;
  hcryp.Init.pKey          = (uint32_t *)pDeviceKeyAES;
  hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_BYTE;

  HAL_CRYP_DeInit(&hcryp);

  if(HAL_CRYP_Init(&hcryp) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  if(HAL_CRYP_Decrypt_DMA(&hcryp, (uint32_t*)InputData, TempLength, (uint32_t*)aDecryptedText) != HAL_OK)
  {
    /* Processing Error */
    Error_Handler();
  }

 
  while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY)
  {
  }
	#if BUG
		uint8_t BufferCounter;
		uint8_t *ArrSerial;
		uint8_t CountBlock = 0;	
	#endif		

	#if BUG
		ArrSerial = InputData;
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA IN AES 128 ECB decryption LAYOUT2 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		APP_PPRINTF( "%d\n\r", TempLength);

		for (BufferCounter = 0; BufferCounter < TempLength; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif		

	#if BUG
		APP_PPRINTF("\n\r =============================================================\n\r");
		APP_PPRINTF(" ================== DATA OUT AES 128 ECB decryption LAYOUT2 =====================\n\r");
		APP_PPRINTF(" =============================================================\n\r");
		APP_PPRINTF(" ---------------------------------------\n\r");
		ArrSerial = (uint8_t*)aDecryptedText;
		for (BufferCounter = 0; BufferCounter < TempLength; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
	#endif

	for(CountCopyData = 0; CountCopyData < TempLength; CountCopyData++)
	{
		OutputData[CountCopyData] =  aDecryptedText[CountCopyData];
	}	
}


/**
  * Enable DMA controller clock
  */
void Smartfram_DMA_Init(void)
{
	  /* DMA controller clock enable */
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
}

/**
  * @brief AES Initialization Function
  * @param None
  * @retval None
  */
void Smartfram_AES_Init(void)
{
	 /* USER CODE BEGIN AES_Init 0 */

  /* USER CODE END AES_Init 0 */

  /* USER CODE BEGIN AES_Init 1 */

  /* USER CODE END AES_Init 1 */
  hcryp.Instance = AES;
  hcryp.Init.DataType = CRYP_DATATYPE_32B;
  hcryp.Init.KeySize = CRYP_KEYSIZE_128B;
  hcryp.Init.pKey = (uint32_t *)pPrivateKeyAES;
  hcryp.Init.Algorithm = CRYP_AES_ECB;
  hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_WORD;
  hcryp.Init.HeaderWidthUnit = CRYP_HEADERWIDTHUNIT_WORD;
  hcryp.Init.KeyIVConfigSkip = CRYP_KEYIVCONFIG_ALWAYS;
  if (HAL_CRYP_Init(&hcryp) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN AES_Init 2 */

  /* USER CODE END AES_Init 2 */
}

void Smartfram_Error_Handler(void)
{
	APP_LOG(1, 1,"loi");
}

void Smartfram_EncryptedLayerTest(uint8_t *InputData, uint8_t Length)
{
	#if 0
		uint8_t aEncryptedText[85]	= {0};
		uint8_t aDecryptedText[85]	= {0};
		uint8_t aInputText[85]			= {0};
		uint8_t aDataReturn[85]			= {0};
		uint8_t *TempInputData = InputData;
		uint8_t TempLength;
		uint8_t CountLength;
		uint8_t CountAddZero;
		
		for(CountLength = 1; CountLength < 6; CountLength++)
		{
			TempLength = 16 * CountLength;
			if(TempLength >= Length)
				break;
			else
				TempLength = 0;
		}
		
		for(CountAddZero = 0; CountAddZero < TempLength; CountAddZero++)
		{
				aInputText[CountAddZero] = *TempInputData++;
		}
		
		
		APP_PPRINTF( "%d\n\r", TempLength);

		#if 1
		uint8_t BufferCounter;
		uint8_t *ArrSerial;
		uint8_t CountBlock = 0;
		ArrSerial = aInputText;
		APP_PPRINTF( "\n-------------------- \n\r");
		for (BufferCounter = 0; BufferCounter < TempLength; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
		#endif
		
		if (HAL_CRYP_DeInit(&hcryp) != HAL_OK)
		{
			Error_Handler();
		}	
		
		hcryp.Instance = AES;
		hcryp.Init.DataType      = CRYP_DATATYPE_8B;
		hcryp.Init.KeySize       = CRYP_KEYSIZE_128B;
		hcryp.Init.Algorithm     = CRYP_AES_ECB;
		hcryp.Init.pKey          = (uint32_t *)pPrivateKeyAES;
		hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_BYTE;

		if (HAL_CRYP_Init(&hcryp) != HAL_OK)
		{
			/* Initialization Error */
			Error_Handler();
		}
		
		if (HAL_CRYP_Encrypt_DMA(&hcryp, (uint32_t*)aInputText, TempLength, (uint32_t*)aEncryptedText) != HAL_OK)
		{
			/* Processing Error */
			Error_Handler();
		}
		while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY){}
		
		#if 1
		APP_PPRINTF( "\n-------------------- \n\r");
		ArrSerial = (uint8_t*)aEncryptedText;
		for (BufferCounter = 0; BufferCounter < TempLength; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
		#endif
		
		HAL_CRYP_DeInit(&hcryp);
		if(HAL_CRYP_Init(&hcryp) != HAL_OK)
		{
			/* Initialization Error */
			Error_Handler();
		}
		if(HAL_CRYP_Decrypt_DMA(&hcryp, (uint32_t*)aEncryptedText, TempLength, (uint32_t*)aDecryptedText) != HAL_OK)
		{
			/* Processing Error */
			Error_Handler();
		}
		while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY){}
			
		#if 1
		ArrSerial = (uint8_t*)aDecryptedText;
		APP_PPRINTF( "\n-------------------- \n\r");
		for (BufferCounter = 0; BufferCounter < TempLength; BufferCounter++)
		{
			APP_PPRINTF("[0x%02X]", *ArrSerial++);
			CountBlock++;
			HAL_Delay(5);
			if (CountBlock == 16)
			{
				CountBlock = 0;
				APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
			}
		}	
		#endif
	#endif
	
}


void Smartfram_FunctionTest(void)
{
	#if 0
	/* Used for storing the encrypted text */
	uint8_t aEncryptedText[128]={0};
	/* Used for storing the decrypted text */
	uint8_t aDecryptedText[128] ={0};

	joinRequetstMsg_t DATA, *datad;
	DATA.Header = 0x1213;
	DATA.TypeMsg = 0x14;
	DATA.MacAdress[0] = 0x1;
	DATA.MacAdress[1] = 0x2;
	DATA.MacAdress[2] = 0x3;
	DATA.MacAdress[3] = 0x4;
	DATA.MacAdress[4] = 0x5;
	DATA.MacAdress[5] = 0x6;
	DATA.Crc = 0x18;
	
	uint32_t BufferCounter = 0;
  uint32_t count = 0;
  uint8_t * ptr = (uint8_t *)&DATA;
	uint8_t *data;
	uint8_t TempDataIN[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};	
	for ( BufferCounter = 10; BufferCounter < 16; BufferCounter++)
	{
		ptr[BufferCounter] = 0x00;
	}
	
  if (HAL_CRYP_DeInit(&hcryp) != HAL_OK)
  {
    Error_Handler();
  }	
	
  hcryp.Instance = AES;
  hcryp.Init.DataType      = CRYP_DATATYPE_8B;
  hcryp.Init.KeySize       = CRYP_KEYSIZE_128B;
  hcryp.Init.Algorithm     = CRYP_AES_ECB;
  hcryp.Init.pKey          = (uint32_t *)pPrivateKeyAES;
  hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_BYTE;

  if (HAL_CRYP_Init(&hcryp) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  if (HAL_CRYP_Encrypt_DMA(&hcryp, TempDataIN, 16, (uint32_t*)aEncryptedText) != HAL_OK)
  {
    /* Processing Error */
    Error_Handler();
  }

  
  while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY)
  {
  }
	
		data = aEncryptedText;
	for (BufferCounter = 0; BufferCounter < 16; BufferCounter++)
  {
    APP_PPRINTF("[0x%02X]", *data++);
    count++;
		HAL_Delay(5);
    if (count == 16)
    {
      count = 0;
      APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
    }
  }	
	 hcryp.Instance = AES;
  hcryp.Init.DataType      = CRYP_DATATYPE_8B;
  hcryp.Init.KeySize       = CRYP_KEYSIZE_128B;
  hcryp.Init.Algorithm     = CRYP_AES_ECB;
  hcryp.Init.pKey          = (uint32_t *)pPrivateKeyAES;
  hcryp.Init.DataWidthUnit = CRYP_DATAWIDTHUNIT_BYTE;
  HAL_CRYP_DeInit(&hcryp);


  if(HAL_CRYP_Init(&hcryp) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }

  if(HAL_CRYP_Decrypt_DMA(&hcryp, (uint32_t*)aEncryptedText, 16, (uint32_t*)aDecryptedText) != HAL_OK)
  {
    /* Processing Error */
    Error_Handler();
  }

 
  while (HAL_CRYP_GetState(&hcryp) != HAL_CRYP_STATE_READY)
  {
  }
	
	data = aDecryptedText;
	for (BufferCounter = 0; BufferCounter < 16; BufferCounter++)
  {
    APP_PPRINTF("[0x%02X]", *data++);
    count++;
		HAL_Delay(5);
    if (count == 16)
    {
      count = 0;
      APP_PPRINTF(" Blocka %d \n\r", BufferCounter / 16);
    }
  }	
	
	#endif
	HAL_Delay(85);
}