
#ifndef __ENCRYPTION_H__
#define __ENCRYPTION_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "sys_app.h"


void Smartfram_Error_Handler(void);

void Smartfram_DMA_Init(void);
void Smartfram_AES_Init(void);

void Smartfram_EncryptedLayer1(uint8_t *InputData, uint8_t Length, uint8_t *OutputData);
void Smartfram_EncryptedLayer2(uint8_t *InputData, uint8_t Length, uint8_t *OutputData);

void Smartfram_DecryptedLayer1(uint8_t *InputData, uint8_t Length, uint8_t *OutputData);
void Smartfram_DecryptedLayer2(uint8_t *InputData, uint8_t Length, uint8_t *OutputData);

void Smartfram_FunctionTest(void);
void Smartfram_EncryptedLayerTest(uint8_t *InputData, uint8_t Length);
#ifdef __cplusplus
}
#endif

#endif
