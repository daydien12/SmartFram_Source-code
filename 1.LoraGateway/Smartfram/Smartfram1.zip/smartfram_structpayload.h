
#ifndef __STRUCTPAYLOAD_H__
#define __STRUCTPAYLOAD_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"
/***
encrypted: |
unencrypted: /
*/
typedef struct
{
	uint16_t Header;			// 2 byte |
	uint8_t TypeMsg;			// 1 byte |
	uint8_t Crc;					// 1 byte |
	uint8_t MacAdress[6]; // 6 byte |
}joinRequetstMsg_t;			// 10 byte 

typedef struct
{
	uint16_t Header;			// 2  byte |
	uint8_t TypeMsg;			// 1  byte |
	uint8_t Crc;					// 1  byte |
	uint8_t MacAdress[6];	// 6  byte |
	uint8_t Netkey[16];		// 16 byte |
}joinAcceptMsg_t;				// 26 byte 


typedef struct
{
	uint16_t Header;			// 2 byte /
	uint8_t TypeMsg;			// 1 byte /
	uint8_t Crc;					// 1 byte /
	
	uint8_t MacAdress[6];	// 6 byte |
	uint8_t Devkey[16];		// 16 byte |
}joinConfirmMsg_t;			// 26 byte 


typedef struct
{
	uint16_t Header;			// 2 byte /
	uint8_t TypeMsg;			// 1 byte /
	uint8_t Crc;					// 1 byte /
	
	uint8_t MacAdress[6];	// 6 byte |
	uint16_t Unicast;			// 2 byte |
}joinCompletedMsg_t;		// 12 byte 


typedef struct
{
	uint16_t Header;			// 2 byte /
	uint8_t TypeMsg;			// 1 byte /
	uint8_t Crc;					// 1 byte /
	uint16_t Unicast;			// 2 byte /
	
	uint16_t IdMsg;				// 2 byte |
	uint16_t Length;			// 2 byte |
	uint8_t Msg[64];			// 64 byte |
}msgDeviceGetway_t;			// 74 byte 


#ifdef __cplusplus
}
#endif

#endif
